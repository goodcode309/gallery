/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 80016
Source Host           : localhost:3306
Source Database       : aaaa

Target Server Type    : MYSQL
Target Server Version : 80016
File Encoding         : 65001

Date: 2021-10-22 11:34:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for painting
-- ----------------------------
DROP TABLE IF EXISTS `painting`;
CREATE TABLE `painting` (
  `painting_id` int(11) NOT NULL AUTO_INCREMENT,
  `painting_name` varchar(255) DEFAULT NULL,
  `painting_path` varchar(255) DEFAULT NULL,
  `house_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`painting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of painting
-- ----------------------------
INSERT INTO `painting` VALUES ('1', '一篮子苹果', '梵高/一篮子苹果.jpg', '1');
INSERT INTO `painting` VALUES ('2', '丰收的季节', '梵高/丰收的季节.jpg', '1');
INSERT INTO `painting` VALUES ('3', '吃马铃薯的人', '梵高/吃马铃薯的人.jpg', '1');
INSERT INTO `painting` VALUES ('4', '埃顿花园的回忆', '梵高/埃顿花园的回忆.jpg', '1');
INSERT INTO `painting` VALUES ('5', '夜间咖啡馆', '梵高/夜咖啡馆.jpg', '1');
INSERT INTO `painting` VALUES ('6', '小树林', '梵高/小树林.jpg', '1');
INSERT INTO `painting` VALUES ('7', '暴风雨的天空', '梵高/暴风雨的天空.jpg', '1');
INSERT INTO `painting` VALUES ('8', '有乌鸦的麦田', '梵高/有乌鸦的麦田.jpg', '1');
INSERT INTO `painting` VALUES ('9', '聚会', '梵高/聚会.jpg', '1');
INSERT INTO `painting` VALUES ('10', '落日下的深秋', '梵高/落日下的深秋.jpg', '1');
INSERT INTO `painting` VALUES ('11', '阿姆斯特丹的海边', '梵高/阿姆斯特丹的海边.jpg', '1');
INSERT INTO `painting` VALUES ('12', '风车小镇', '梵高/风车小镇.jpg', '1');
INSERT INTO `painting` VALUES ('13', '坐在公园里的女子', '毕加索/坐在公园里的女子.jpg', '2');
INSERT INTO `painting` VALUES ('14', '坐在扶手椅上的女子', '毕加索/坐在扶手椅上的女子.jpg', '2');
INSERT INTO `painting` VALUES ('15', '女子和公鸡', '毕加索/女子和公鸡.jpg', '2');
INSERT INTO `painting` VALUES ('16', '室内的女子', '毕加索/室内的女子.jpg', '2');
INSERT INTO `painting` VALUES ('17', '沐浴', '毕加索/沐浴.jpg', '2');
INSERT INTO `painting` VALUES ('18', '牛头骨', '毕加索/牛头骨.jpg', '2');
INSERT INTO `painting` VALUES ('19', '画室', '毕加索/画室.jpg', '2');
INSERT INTO `painting` VALUES ('20', '画家和模特儿', '毕加索/画家和模特儿.jpg', '2');
INSERT INTO `painting` VALUES ('21', '缝纫的女人周围环绕着她的孩子们', '毕加索/缝纫的女人周围环绕着她的孩子们.jpg', '2');
INSERT INTO `painting` VALUES ('22', '背对着镜子入睡的裸女', '毕加索/背对着镜子入睡的裸女.jpg', '2');
INSERT INTO `painting` VALUES ('23', '镜前少女', '毕加索/镜前少女', '2');
INSERT INTO `painting` VALUES ('24', '丽达与鹅', '达芬奇/丽达与鹅.jpg', '3');
INSERT INTO `painting` VALUES ('25', '吉内薇拉·班琪', '达芬奇/吉内薇拉·班琪.jpg', '3');
INSERT INTO `painting` VALUES ('26', '哺乳圣母', '达芬奇/哺乳圣母.jpg', '3');
INSERT INTO `painting` VALUES ('27', '圣母子与圣安妮', '达芬奇/圣母子与圣安妮.jpg', '3');
INSERT INTO `painting` VALUES ('28', '基督受洗', '达芬奇/基督受洗.jpg', '3');
INSERT INTO `painting` VALUES ('29', '基督的洗礼', '达芬奇/基督的洗礼.jpg', '3');
INSERT INTO `painting` VALUES ('30', '安吉里之战', '达芬奇/安吉里之战.jpg', '3');
INSERT INTO `painting` VALUES ('31', '抱貂女郎', '达芬奇/抱貂女郎.jpg', '3');
INSERT INTO `painting` VALUES ('32', '持康乃馨的圣母', '达芬奇/持康乃馨的圣母.jpg', '3');
INSERT INTO `painting` VALUES ('33', '纺车边的圣母', '达芬奇/纺车边的圣母.jpg', '3');
INSERT INTO `painting` VALUES ('34', '维特鲁威人', '达芬奇/维特鲁威人.jpg', '3');
INSERT INTO `painting` VALUES ('35', '蒙娜丽莎的微笑', '达芬奇/蒙娜丽莎的微笑.jpg', '3');
